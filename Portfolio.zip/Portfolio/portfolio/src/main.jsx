import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import NavBar from '../src/components/navbar/navbar.jsx'
import Intro from '../src/components/intro/intro.jsx'
import Skills from '../src/components/skills/skills.jsx'
import Skill from '../src/components/skills1/skills1.jsx'
import Experience from '../src/components/experience/experience.jsx'
import Contact from '../src/components/contact/contact.jsx';
import Footer from '../src/components/footer/footer.jsx';
import Layout from '../src/Layout.jsx';
import {Route,RouterProvider,createBrowserRouter,createRoutesFromElements} from 'react-router-dom';



const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<Layout/>}>
      <Route path='' element={<Intro/>} ></Route>
    </Route>
  )
)

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
    <NavBar/>
    <Intro></Intro>
    <Skills></Skills>
    <Skill></Skill>
    <Experience></Experience>
    <Contact></Contact>
    <Footer></Footer>
    
  </StrictMode>,
)
