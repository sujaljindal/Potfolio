import React from "react";
import './footer.css';

const Footer =()=>{
    return(
        <footer className="footer">
            Copyrigth &#169; 204 Sujal Jindal. All right recieved.
        </footer>
    )
}

export default Footer;