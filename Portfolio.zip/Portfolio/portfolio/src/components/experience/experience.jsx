import React from "react";
import './experience.css';
import expimg from '../../assets/nexg.png';


const Experience =()=>{
    return(
        <section className="exp">
            <span className="headTitle">Experience</span>
            <div className="expBar">
                <div className="expsBar">
                    <img src={expimg} alt="" className="expBarImg" />
                    <div className="expBarText">
                        <h1>Software Traniee, NexGen Tech Solutions</h1>
                        <h3>October 2024 - Present</h3>
                    </div>
                </div>
                
            </div>

        </section>
    )
} 
export default Experience;