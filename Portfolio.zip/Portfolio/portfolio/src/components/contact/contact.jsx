import React from "react";
import './contact.css';
import linkedin from '../../assets/Linkedin_icon.svg.png';
import github from '../../assets/github.png';
import insta from '../../assets/insta.webp';

const Contact = ()=>{
    return(
        <div className="contact">
            <h1 className="contactTitle">Contact Me</h1>
            <span className="contactDesc">Please fill out the form below to discuss any work opportunities.</span>
            <form className="contactForm" action="">
                <input type="text" className="name" placeholder="Your Name" />
                <input type="email" className="email" placeholder="Your Email" />
                <textarea className='msg' name="message" rows="8" placeholder="Your Message"></textarea>
                <button type='submit' className="submit">Submit</button>
                <div className="links">
                    <img src={linkedin} alt="Linkedin" className="link" />
                    <img src={github} alt="Github" className="link" />
                    <img src={insta} alt="Instagram" className="link" />
                    {/* <img src={} alt="" className="link" /> */}
                </div>

            </form>
        </div>
    )
}

export default Contact;