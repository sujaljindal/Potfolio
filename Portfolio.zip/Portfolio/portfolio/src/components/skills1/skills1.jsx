import React from "react";
import './skills1.css';
import html from '../../assets/skills/html.webp';
import css from '../../assets/skills/css.png';
import js from '../../assets/skills/javascript.png';
import react from '../../assets/skills/react.png';
import mysql from '../../assets/skills/mysql.png';
import java from '../../assets/skills/java.svg';
import python from '../../assets/skills/python.png'


const Skill =()=>{
    return(
        <section className="skill">
            <span className="headTitle">Skills</span>
            <div className="skillsBars">
                <div className="skillBars">
                    <img src={html} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>HTML</h2>
                        
                    </div>
                </div>
                <div className="skillBars">
                    <img src={css} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>CSS</h2>
                        
                    </div>
                </div>
                <div className="skillBars">
                    <img src={js} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>JavaScript</h2>
                        
                    </div>
                </div>
                <div className="skillBars">
                    <img src={react} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>React</h2>
                        
                    </div>
                </div>
                <div className="skillBars">
                    <img src={mysql} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>MySQL</h2>
                        
                    </div>
                </div>
                <div className="skillBars">
                    <img src={java} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>Java</h2>
                        
                    </div>
                </div>
                <div className="skillBars">
                    <img src={python} alt="" className="skillBarsImg" />
                    <div className="skillBarsText">
                        <h2>Python</h2>
                        
                    </div>
                </div>
            </div>

        </section>
    )
}

export default Skill;