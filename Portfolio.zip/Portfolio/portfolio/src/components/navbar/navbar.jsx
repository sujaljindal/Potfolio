import React from "react";
import './navbar.css';
import call from '../../assets/contact.png';
import logo from '../../assets/logo.svg';
import {Link} from 'react-scroll';

const NavBar= () =>{
    return(
        <nav className="navbar">
            <img src={logo} alt="Logo" className="logo" />
            <div className="desktopMenu">
                <Link to="/" className="desktopMenuList" >Home</Link>
                <Link className="desktopMenuList" >About</Link>
                <Link className="desktopMenuList" >Skills</Link>
                <Link className="desktopMenuList" >Experience</Link>
                <Link className="desktopMenuList" >Projects</Link>

                
            </div>
            <button className="desktopMenuBtn">
                <img src={call} alt="" className="desktopMenuIcon" />Contact Me</button>
                
        </nav>
    )
} 

export default NavBar;