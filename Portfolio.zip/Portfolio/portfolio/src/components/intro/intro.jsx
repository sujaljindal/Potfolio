import React from "react";
import './intro.css';
import me from '../../assets/Me.png';
import {Link} from 'react-scroll'
import hire from '../../assets/hire.png'

const Intro =() =>{
    return(
        <section className="intro">
            <div className="introContent">
                <span className="hello">Hello,</span>
                <span className="introText">I'm <span className="introName">Sujal Jindal</span><br />Website Designer</span>
                <p className="introPara">I am a skilled web designer with experience in creating <br />visually appealing and user friendly websites.</p>
                <div className="buttonContainer">
                <Link><button className="btn"><img src={hire} alt="" className="hireImg"/>hire Me</button></Link>
                
                <Link><button className="btn"><img src={hire} alt="" className="hireImg"/>My Resume</button></Link>
                </div>
            </div>

            <img src={me} alt=""  className="myImage"/>

        </section>
    )
}

export default Intro;